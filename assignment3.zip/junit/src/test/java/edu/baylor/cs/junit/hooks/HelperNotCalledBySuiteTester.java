package edu.baylor.cs.junit.hooks;

import org.junit.jupiter.api.Test;

public class HelperNotCalledBySuiteTester {
	@Test
	void test() {
	}
}
