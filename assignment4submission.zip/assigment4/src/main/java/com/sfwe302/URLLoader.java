package com.sfwe302;

public abstract class URLLoader {
    
    protected abstract void processLine(String[] tokens);

}
