package edu.baylor.ecs.si;

public class MountainBikeHolder extends BicycleHolder {
    public MountainBikeHolder(MountainBike bicycle) {
		super(bicycle);
	}
}
